#!/bin/sh
cat /sdcard/rocknix_abl/abl/ablScTool > /data/local/tmp/ablScTool
chmod 777 /data/local/tmp/ablScTool
/data/local/tmp/ablScTool ANY backup >> /data/local/tmp/output.txt 2>&1
rm /data/local/tmp/ablScTool
